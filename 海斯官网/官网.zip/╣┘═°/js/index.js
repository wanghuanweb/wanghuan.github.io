$(document).ready(function() {

    var headerCommon = window.frames("myframe").document.getElementById("header").innerHTML;
    document.getElementById("header").innerHTML = headerCommon;

    var count = 1;
    var time = null;

    // switch banner
    $(".banner .banner-list").eq(0).show().siblings("div").hide();

    $(".banner .banner-btns li").click(function() {
        // 索引是1-4的时候
        count = $(this).index();
        $(this).addClass("hov").siblings("li").removeClass("hov");
        $(".banner .banner-list").eq(count-1).fadeIn(1000).siblings("div").fadeOut(1000);
    });

    $(".banner").mouseover(function(event) {
        /* Act on the event */
        clearInterval(time);
    }).mouseout(function(event) {
        /* Act on the event */
        autoPlay();
    });

    autoPlay();

    $("#fullpage").fullpage({
        'verticalCentered': false,
        'resize':true,
        'scrollingSpeed':700,
        'css3': true,
        // 'sectionsColor': ['#254875', '#00FF00', '#254587', '#695684'],
        anchors: ['Focus and speciality', 'Product features', 'Standard features', 'Service content','Contact us'],
        'navigation': true,
        'navigationPosition': 'right',
        'navigationTooltips': ['focus and speciality', 'Product features', 'Standard features', 'service content']
    });

    function autoPlay() {
        time = setInterval(function() {
            count++;
            if(count <= 4) {
                $(".banner .banner-btns li").eq(count).addClass('hov').siblings().removeClass('hov');
                $(".banner .banner-list").eq(count-1).fadeIn(1000).siblings("div").fadeOut(500);
            } else {
                count = count - 1;
            }
        },2000);
    }

    // animation of product features
});
