/**
 * load(url [.data] [.callback])方法：jquery最常用的Ajax方法，可以载入远程HTML代码并插入到DOM中
 * @param url(String)-请求HTML页面的url地址
 * @param data(Object)-可选，发送到服务器的key/value数据
 * @param callback(Function)-请求完成时的回调函数，无论请求成功或失败
 */
$(function(){
    $("#send").click(function() {
        alert("w");
        $("#resText").load("test.html");
    });
});
